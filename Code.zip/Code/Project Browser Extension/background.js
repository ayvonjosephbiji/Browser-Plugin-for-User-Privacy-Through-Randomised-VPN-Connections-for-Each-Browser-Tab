if (typeof browser === "undefined") {
    var browser = chrome;
};
/* function openTab(){
    
    var newTab = browser.tabs.create({
        url:'https://twitter.com',
        active:true
    })
}

browser.browserAction.onClicked.addListener(openTab) */

