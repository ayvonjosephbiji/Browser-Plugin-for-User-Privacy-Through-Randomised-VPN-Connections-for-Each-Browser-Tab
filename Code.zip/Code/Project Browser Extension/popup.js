document.addEventListener("DOMContentLoaded", function() {
    document.querySelector("#mySwitch input").addEventListener("change", function() {
        var statusText = document.querySelector(".status");
        if (this.checked) {
            console.log("Switch is ON");
            statusText.textContent = "Connected";
            // Save the state to chrome.storage
            chrome.storage.sync.set({switchState: true}, function() {
                console.log('Switch state is set to ' + true);
            });
        } else {
            console.log("Switch is OFF");
            statusText.textContent = "Disconnected";
            // Save the state to chrome.storage
            chrome.storage.sync.set({switchState: false}, function() {
                console.log('Switch state is set to ' + false);
            });
        }
    });

    // On startup, check the saved state and update the switch
    chrome.storage.sync.get('switchState', function(data) {
        document.querySelector("#mySwitch input").checked = data.switchState;
        document.querySelector(".status").textContent = data.switchState ? "Connected" : "Disconnected";
    });
});
